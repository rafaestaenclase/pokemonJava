package pokemon;

import GUI.CombatWindow;
import GUI.SelectPokemonWindow;
import java.sql.SQLException;
import java.util.ArrayList;
import model.bd.LoadPokemon;

import model.clases.Pokemon;
public class main {

    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        new CombatWindow().setVisible(true);
    }
    
    public static Pokemon loadEnemy() throws SQLException, ClassNotFoundException{
        
        Pokemon pokemon = LoadPokemon.loadEnemy();
        return pokemon;
        
    }
    
        public static Pokemon loadFriend(int selected) throws SQLException, ClassNotFoundException{
        
        Pokemon pokemon = LoadPokemon.loadFriend(selected);
        return pokemon;
        
    }
    
    public static ArrayList <Pokemon> loadAllPokemon() throws SQLException, ClassNotFoundException{
        ArrayList pokemons = LoadPokemon.loadAllPokemon();
        return pokemons;
        
    }
    
}
